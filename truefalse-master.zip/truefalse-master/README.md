                                                  Game tính nhẩm
1. Giới thiệu: Là tựa game tính toán, giúp trẻ em rèn luyện khả năng tính nhẩm các phép tính tiến (cộng và nhân). 
2. Cách chơi: Mỗi lượt chơi có tối đa là một phút. Trong một phút đó bạn phải hoàn thành được nhiều đáp án đúng nhất. Mỗi lần chọn đáp án đúng bạn sẽ được cộng 1 điểm, ngược lại nếu sai bạn sẽ bị trừ đi 1 điểm. Khi hết thời gian sẽ hiện số điểm bạn đạt được sau khi chơi

3. Phát triển
- Công cụ phát triển: Android studio 3.2
- minSdkVersion: 16
- targetSdkVersion: 28
- compileSdkVersion 28
